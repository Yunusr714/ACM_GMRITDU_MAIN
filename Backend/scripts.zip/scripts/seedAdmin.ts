import { AppDataSource } from "../src/config/data-source";
import { Admin } from "../src/entities/Admin";
import bcrypt from "bcryptjs";

async function seedAdmin() {
    try {
        await AppDataSource.initialize();
        console.log("Database connection established.");

        const adminRepository = AppDataSource.getRepository(Admin);
        
        const username = "ACM_GMRITDU2026";
        const password = "ACM_GMRITDU_ADMIN";

        const existingAdmin = await adminRepository.findOne({ where: { username } });
        if (existingAdmin) {
            console.log("Admin user already exists!");
            process.exit(0);
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const admin = new Admin();
        admin.username = username;
        admin.password = hashedPassword;

        await adminRepository.save(admin);

        console.log("Admin user created successfully!");
    } catch (error) {
        console.error("Error seeding admin user:", error);
    } finally {
        await AppDataSource.destroy();
        process.exit(0);
    }
}

seedAdmin();
